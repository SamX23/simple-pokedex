# Simple Pokedex Using Webpack

[Home Page]("https://github.com/SamX23/simple-pokedex/blob/master/screenshot/pokemon.png")

## How to use

Clone repo
'gh repo clone SamX23/simple-pokedex'

Install dependencies
'npm run install'

Start development
'npm run start'

Building apps
'npm run build'

[LIVE]["https://samx23.github.io/simple-pokedex/"]
